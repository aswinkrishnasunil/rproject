import folium
import streamlit as st
import pandas as pd
from streamlit_folium import st_folium
from folium import plugins

def load_data():
    # Load CSV data
    ship_data = pd.read_csv(
        "C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\imo_tracking.csv")
    ports_data = pd.read_csv(
        "C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\ports.csv")
    regions_data = pd.read_csv(
        "C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\regions.csv")
    yy_ship_count_data = pd.read_csv(
        "C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\yy_ship_count.csv")

    return ship_data, ports_data, regions_data, yy_ship_count_data


def port_marker(ports_data):
    map = folium.Map(location=[38.402643000000000, -76.384919400000000], zoom_start=3)
    folium.TileLayer('cartodbpositron').add_to(map)
    # map.fit_bounds([[90, -180], [-90, 180]])

    import_ports = ports_data[ports_data['category']== 'Import'].reset_index(drop=True)
    export_ports = ports_data[ports_data['category']!= 'Import'].reset_index(drop=True)
    for i in range(len(import_ports)):
        folium.Marker(location=import_ports.iloc[i][['lat', 'lon']].to_list(),
                      popup=f"Name: {import_ports.iloc[i]['name']} <br> "
                            f"Type: {import_ports.iloc[i]['category']} <br> "
                            f"Country: {import_ports.iloc[i]['country']}",
                      icon=folium.features.CustomIcon('import.png', icon_size=(15,20))
                      ).add_to(map)
    for i in range(len(export_ports)):
        folium.Marker(location=export_ports.iloc[i][['lat', 'lon']].to_list(),
                      popup=f"Name: {export_ports.iloc[i]['name']} <br> "
                            f"Type: {export_ports.iloc[i]['category']} <br> "
                            f"Country: {export_ports.iloc[i]['country']}",
                      icon=folium.features.CustomIcon('export.png', icon_size=(15,20))
                      ).add_to(map)
    return map


def ship_map(map, ship_data):
    imos = list(set(ship_data.imo))
    # ship_data['addition'] = 0
    # ship_data.loc[ship_data.lon > 180 , 'addition'] = -360
    # ship_data.loc[ship_data.lon < -180, 'addition'] = 360
    # ship_data['lon'] = ship_data['lon'] + ship_data['addition']
    ship_data = ship_data.drop_duplicates(subset=['lat', 'lon'])
    for i in imos:
        # if i != 9630004:
        #     continue
        imo_data = ship_data[ship_data.imo == i].reset_index(drop=True)
        imo_data_neg = imo_data[imo_data.lon < 0].sort_values(by='seen_date', ascending=True).reset_index(drop=True)
        imo_data_pos = imo_data[imo_data.lon >= 0].sort_values(by='seen_date', ascending=True).reset_index(drop=True)
        polyLines = []

        if len(imo_data_pos) > 0:
            # folium.PolyLine(locations=imo_data_pos[['lat', 'lon']].values.tolist()).add_to(map, name=f'{i}')
            polyLines.append(folium.PolyLine(locations=imo_data_pos[['lat', 'lon']].values.tolist()))
        if len(imo_data_neg) > 0:
            # folium.PolyLine(locations=imo_data_neg[['lat', 'lon']].values.tolist()).add_to(map, name=f'{i}')
            polyLines.append(folium.PolyLine(locations=imo_data_neg[['lat', 'lon']].values.tolist()))

        for poly in polyLines:
            poly.add_to(map)


    # Use the MousePosition plugin to show popups on mouse hover
    # plugins.MousePosition(position="topright").add_to(map)
    st_map = st_folium(map, width=1500, height=600)

    return

def main():
    st.set_page_config('Ship Map', layout="wide")
    ship_data, ports_data, regions_data, yy_ship_count_data = load_data()

    # st.write(regions_data.columns)
    sub_region_list = list(set(regions_data.sub_region))
    # sub_region = st.sidebar.multiselect('sub_region', sub_region_list, default=sub_region_list)
    # sub_region_f = []
    sub_region = sub_region_list
    if st.sidebar.button('Select All'):
        sub_region = sub_region_list
    if st.sidebar.button('Unelect All'):
        sub_region = []
    # sub_region = st.sidebar.multiselect('sub_region', sub_region_f, default=sub_region_f)
    ship_data_f = ship_data[ship_data.sub_region.isin(sub_region)]
    # st.write()
    map = port_marker(ports_data)
    ship_map(map, ship_data_f)
    # st.write(imo_data_pos.head(15))
    # st.write(imo_data_neg.head(15))
    # st.write(ship_data.head(10))




if __name__ == "__main__":
    main()


print('Done')