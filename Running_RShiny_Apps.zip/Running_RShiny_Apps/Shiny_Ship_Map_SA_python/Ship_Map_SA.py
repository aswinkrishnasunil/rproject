from flask import Flask, render_template, request, jsonify
import pandas as pd
import folium
from folium.plugins import MarkerCluster

app = Flask(__name__)

# Load CSV data
ship_data = pd.read_csv("C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\imo_tracking.csv")
ports_data = pd.read_csv("C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\ports.csv")
regions_data = pd.read_csv("C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\regions.csv")
yy_ship_count_data = pd.read_csv("C:\\Users\\devuser\\PycharmProjects\\omkar_projects\\LNG_Ships_Model_Python\\data\\yy_ship_count.csv")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        # Handle form submissions here
        hour_input = int(request.form.get("hourInput"))
        dest_cb = request.form.getlist("dest_cb")
        # Handle other form inputs similarly
        # Perform data processing based on user inputs

    return render_template("index.html")

@app.route("/map")
def map():
    # Create a map using Folium
    m = folium.Map(location=[29.7269629, -93.8740505], zoom_start=4)

    # Add markers for ship locations
    ship_markers = MarkerCluster().add_to(m)
    for idx, row in ship_data.iterrows():
        folium.Marker(
            location=[row["lat"], row["lon"]],
            popup=f"IMO: {row['imo']}",
        ).add_to(ship_markers)

    return m._repr_html_()

@app.route("/ship_count")
def ship_count():
    # Perform ship count calculations based on filters
    # Return ship count data as JSON
    # Example: ship_count_data = {"full": 100, "empty": 50, "total": 150}
    ship_count_data = {}  # Replace with your ship count logic
    return jsonify(ship_count_data)

if __name__ == "__main__":
    app.run(debug=True)
