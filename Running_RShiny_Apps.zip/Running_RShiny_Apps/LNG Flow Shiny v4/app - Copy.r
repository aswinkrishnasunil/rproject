#shiny::runApp("J:/_Eric Anderson/NG Analysis/LNG/LNG Flow Shiny v4")
#added forecast progression

library(shiny)
library(ggplot2)
library(lubridate)
library(zoo)
library(grid)
library(gridExtra)
library(plotly)
library(reshape2)
library(RODBC)

options(scipen=999)


region_cat <- data.frame(region=c("North America","Asia Pacific","Western Europe","South & Central America","Asia Pacific","Western Europe",
	"Western Europe","North America","Western Europe","Asia Pacific","Asia Pacific","Central Asia","Eastern Europe","South & Central America",
	"Australia","Africa","Western Europe","Middle East","South & Central America","Africa","Asia Pacific","North America","Middle East","North America",
	"North America","North America","Eastern Europe", "Africa", "Eastern Europe", "s2s"),
	sub_region = c("US East Coast","China","Northwest Europe","North SA","South Korea","Italy","UK","Caribbean","Iberian Europe",
		"Southeast Asia","Japan","Central Asia","Southeast Europe","East SA","Australia","North Africa","Scandinavia","Gulf of Oman",
		"West SA","West Africa","South Russia","MX Gulf Coast","Suez","US West Coast","Mexico Pacific","US Gulf Coast","North Russia",
		"East Africa", "West Russia", "s2s"))
region_cat$region <- as.character(region_cat$region)
region_cat$sub_region <- as.character(region_cat$sub_region)

shinyApp(
ui <- fluidPage(
	sidebarLayout(
		sidebarPanel(
			selectInput("region","Select Region",c("All","Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East",
				"North America","South & Central America","Western Europe", "s2s")),
			selectInput("sub_region","Select Sub Region",c("All")),
			dateRangeInput("daterng","Select Date Range",Sys.Date()-90,Sys.Date()+30),
			sliderInput("sma","Select Moving Average",1,21,7),
			checkboxGroupInput("region_include","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","NULL","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","NULL","South & Central America","Western Europe", "s2s")),
			actionLink("selectall","Select/Unselect All"),
			sliderInput("fp","Select Prior Forecast (Days ago)",1,7,1),
			width=3
		),
		
		mainPanel(
			tabsetPanel(type="tabs",
				tabPanel("Chart",
					div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("bcf_count","Select Units",c("Bcf/d","Ships/d"),inline=T)),
					div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("chart_series","Graph Series",c("True","False"),inline=T)),
					textOutput("imports"),
					uiOutput("import_chart"),
					textOutput("exports"),
					uiOutput("export_chart"),
					textOutput("net"),
					plotlyOutput("net_chart",height="385"),
					width=9,
					tags$head(tags$style("#imports{
						font-size: 15px;
						}#exports{
						font-size: 15px;
						}#net{
						font-size: 15px;
						}")
					)
				),
				tabPanel("Data",
					downloadButton("downloadData", "Download"),
					dataTableOutput("data_table")
				)
			)
		)

	)
),
server <- function(input, output, session) {
	output$imports <- renderText({"Imports"})
	output$exports <- renderText({"Exports"})
	output$net <- renderText({"Net"})
	
	#select/unselect all regions hyperlink
	observe({
		if(input$selectall == 0) return(NULL) 
		else if (input$selectall%%2 == 0){
			updateCheckboxGroupInput(session,"region_include","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","NULL","South & Central America","Western Europe", "s2s"))
		}else{
			updateCheckboxGroupInput(session,"region_include","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","NULL","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","NULL","South & Central America","Western Europe", "s2s"))
		}
	})
	
	#update sub_region dropdown
	observe({
		updateSelectInput(session,"sub_region",choices=c("All",region_cat$sub_region[which(region_cat$region==input$region)]))
	})
	
	fp_data <- reactive({
		data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/uo95hdbmzkd9z2zw3skqg/LNG_Region_Flow_Historical_Forecasts.csv?rlkey=i66yrajmnm1ztwheuawj7gpw9&dl=0",header=TRUE)
		data$date <- as.Date(data$date)
		data$region <- as.character(data$region)
		data$subregion <- as.character(data$subregion)
		data$region2 <- as.character(data$region2)
		data$subregion2 <- as.character(data$subregion2)
		
		data[is.na(data)] <- "NULL"
		
		return(data)
	})
	
	#get forecast progression
	fp <- reactive({
		data <- fp_data()
		data <- data[which(data$t==input$fp),]
		
		return(data)
	})
	
	dataInput <- reactive({
		data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/er4bopalk1pq0nem2nj37/LNG_flow_L2.csv?rlkey=j8bkrb5zize9a79ld7of552tf&dl=0",header=TRUE)
		data$date <- as.Date(data$date)
		data$region <- as.character(data$region)
		data$subregion <- as.character(data$subregion)
		data$region2 <- as.character(data$region2)
		data$subregion2 <- as.character(data$subregion2)
		
		data[is.na(data)] <- "NULL"
		
		return(data)
	})
	
	# dataInput_blend <- reactive({
		# data <- dataInput()
		
		# if(as.Date(input$daterng[1]) < as.Date('2019-01-01') | as.Date(input$daterng[2]) < as.Date('2019-01-01')){
			# if(!exists("data2")) data2 <- read.csv("https://www.dropbox.com/s/ki5pton9duqem9s/LNG%20flow%20L2%20Historic.csv?dl=1",colClasses=c("numeric","character","character","character","character","Date","character","numeric"))
			# data2$idle <- 0
			# data2[is.na(data2)] <- "NULL"
			
			# data <- rbind(data,data2)
		# }
		
		# return(data)
	# })
	
	output$import_chart <- renderUI({
		if(input$bcf_count=="Bcf/d"){
			plotlyOutput("import_plot",width="100%",height="385")
		} else {
			plotlyOutput("import_plot_count",width="100%",height="385")
		}
	})
	
	output$export_chart <- renderUI({
		if(input$bcf_count=="Bcf/d"){
			plotlyOutput("export_plot",width="100%",height="385")
		} else {
			plotlyOutput("export_plot_count",width="100%",height="385")
		}
	})
	
	dl_data <- reactive({
		data <- dataInput() #dataInput_blend
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		data <- data[which(data$region2 %in% input$region_include),]
			
		#filter to region
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(input$region)
		}
		data <- data[which(data$region %in% region_),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}	
		
		data$gas_volume <- data$gas_volume/1000000
		return(data)
	})
	
	output$data_table <- renderDataTable({
		data <- dl_data()
		return(data)
	})
	
	output$downloadData <- downloadHandler(
		filename = "data.csv",
		content = function(file) {
			write.csv(dl_data(), file,row.names=FALSE)
		}
	)
	
	#Ship Count Charts
	dataInput_export_count <- reactive({
		data <- dataInput() # dataInput_blend()
		data <- data[which(data$gas_volume!=0),]
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Export")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(imo~region2+date,data=temp,FUN=length),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$imo[which(is.na(x$imo))] <- 0
				x$region <- input$region
				x$imo <- rollmean(x$imo,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$imo[which(is.na(data2$imo))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		names(data2) <- c("Date","Region","Count","region")
		return(data2)
	})
	
	dataInput_export_count_fp <- reactive({
		data <- fp()
		data <- data[which(data$gas_volume!=0),]
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Export")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(imo~region2+date,data=temp,FUN=length),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$imo[which(is.na(x$imo))] <- 0
				x$region <- input$region
				x$imo <- rollmean(x$imo,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$imo[which(is.na(data2$imo))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		names(data2) <- c("Date","Region","Count","region")
		return(data2)
	})
	
	dataInput_import_count_fp <- reactive({
		data <- fp()
		data <- data[which(data$gas_volume!=0),]
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Import")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(imo~region2+date,data=temp,FUN=length),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$imo[which(is.na(x$imo))] <- 0
				x$region <- input$region
				x$imo <- rollmean(x$imo,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$imo[which(is.na(data2$imo))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		names(data2) <- c("Date","Region","Count","region")
		return(data2)
	})
	
	dataInput_import_count <- reactive({
		data <- dataInput() # dataInput_blend()
		data <- data[which(data$gas_volume!=0),]
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Import")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(imo~region2+date,data=temp,FUN=length),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$imo[which(is.na(x$imo))] <- 0
				x$region <- input$region
				x$imo <- rollmean(x$imo,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$imo[which(is.na(data2$imo))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		names(data2) <- c("Date","Region","Count","region")
		return(data2)
	})
	
	#BCF Charts
	dataInput_export <- reactive({
		data <- dataInput() # dataInput_blend()
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Export")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average (creates flat table of sma by region)
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(gas_volume~region2+date,data=temp,FUN=sum),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$gas_volume[which(is.na(x$gas_volume))] <- 0
				x$region <- input$region
				x$gas_volume <- rollmean(x$gas_volume,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$gas_volume[which(is.na(data2$gas_volume))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		data2$gas_volume <- data2$gas_volume/1000000
		names(data2) <- c("Date","Region","Bcf","region")
		return(data2)
	})
		#BCF chart forecast progression
	dataInput_export_fp <- reactive({
		#input <- data.frame(region="All",sub_region="All",sma=14)
		data <- fp()
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Export")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average (creates flat table of sma by region)
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(gas_volume~region2+date,data=temp,FUN=sum),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$gas_volume[which(is.na(x$gas_volume))] <- 0
				x$region <- input$region
				x$gas_volume <- rollmean(x$gas_volume,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$gas_volume[which(is.na(data2$gas_volume))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		data2$gas_volume <- data2$gas_volume/1000000
		names(data2) <- c("Date","Region","Bcf","region")
		return(data2)
	})
	
	dataInput_import_fp <- reactive({
		#input <- data.frame(region="All",sub_region="All",sma=14)
		data <- fp()
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Central Asia",sma=14)
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(as.character(input$region))
		}
		data <- data[which((data$region %in% region_) & (data$type=="Import")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average (creates flat table of sma by region)
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(gas_volume~region2+date,data=temp,FUN=sum),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$gas_volume[which(is.na(x$gas_volume))] <- 0
				x$region <- input$region
				x$gas_volume <- rollmean(x$gas_volume,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$gas_volume[which(is.na(data2$gas_volume))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		data2$gas_volume <- data2$gas_volume/1000000
		names(data2) <- c("Date","Region","Bcf","region")
		return(data2)
	})
	
	dataInput_import <- reactive({
		data <- dataInput() # dataInput_blend()
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		if(input$region=="All") names(data) <- c("imo","region2","subregion2","region","subregion","date","type","gas_volume","idle")
		data <- data[which(data$region2 %in% input$region_include),]
		#input <- data.frame(region="Africa")
		if(input$region=="All"){
			region_ <- c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe","s2s")
		}else{
			region_ <- c(input$region)
		}
		data <- data[which((data$region %in% region_) & (data$type=="Import")),]
		
		#filter to sub_region
		if(input$sub_region != "All"){
			data <- data[which(data$subregion %in% input$sub_region),]
		}
		
		#calc Moving Average
		data2 <- data.frame(matrix(nrow=0,ncol=4))
		region2 <- as.character(unique(data$region2))
		region2 <- region2[!is.na(region2)]
		for(i in 1:length(region2)){
			temp <- data[which(data$region2==region2[i]),]
			
			if(nrow(temp)>0){
				x <- data.frame(date=seq(min(data$date),max(data$date),"day"))
				x <- merge(x,aggregate(gas_volume~region2+date,data=temp,FUN=sum),by=c("date"),all=TRUE)
				x$region2 <- region2[i]
				x$gas_volume[which(is.na(x$gas_volume))] <- 0
				x$region <- input$region
				x$gas_volume <- rollmean(x$gas_volume,input$sma,na.pad=T,align="right")
				
				data2 <- rbind(data2,x)
			}
		}
		
		data2$gas_volume[which(is.na(data2$gas_volume))] <- 0
		data2 <- data2[order(data2$region2,data2$date),]
		data2$gas_volume <- data2$gas_volume/1000000
		names(data2) <- c("Date","Region","Bcf","region")
		return(data2)
	})
	
	#charts
		
	output$net_chart <- renderPlotly({
		if(input$bcf_count=="Bcf/d"){ #Bcf
			exports <- dataInput_export()
			exports$Bcf <- exports$Bcf * -1
			imports <- dataInput_import()
			
			data <- rbind(exports,imports)
			
			#data$Date <- data$date
			#data$Bcf <- data$gas_volume/1000000
			
			max_ <- aggregate(Bcf~Date,data=data,FUN=sum)
			data <- max_
			max_ <- max(data$Bcf)
			min_ <- min(0,data$Bcf)
			
			p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
				layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
			
			data$TOTAL <- data$Bcf
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
			
			pl <- layout(p,
				shapes=list(list(type = "line",
					fillcolor = "blue", line = list(color = "black"), opacity = 1,
					x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
					y0 =min_, y1=max_,yref = "Bcf")))
		} else { #Count
			exports <- dataInput_export_count()
			exports$Count <- exports$Count * -1
			imports <- dataInput_import_count()
			
			
			
			data <- rbind(exports,imports)
			
			max_ <- aggregate(Count~Date,data=data,FUN=sum)
			data <- max_
			max_ <- max(data$Count)
			min_ <- min(0,data$Count)
			
			p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
				layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
			
			data$TOTAL <- data$Count
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
			
			
			
			pl <- layout(p,
				shapes=list(list(type = "line",
					fillcolor = "blue", line = list(color = "black"), opacity = 1,
					x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
					y0 =min_, y1=max_,yref = "Count")))
		}
	})
		#BCF
	output$export_plot <- renderPlotly({
		data <- dataInput_export()
		
		fp <- dataInput_export_fp()
		fp <- aggregate(Bcf~Date,data=fp,FUN=sum)
		fp <- fp[which(fp$Bcf!=0),]
		
		max_ <- aggregate(Bcf~Date,data=data,FUN=sum)
		max_ <- max(max_$Bcf)
		
		data <- dcast(data[,c("Region","Bcf","Date")],Date~Region,value.var="Bcf",fun.aggregate=sum)
		
		p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
			layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')	
		
		if(input$chart_series=="True"){
			if("Africa" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Africa', name = 'Africa',fillcolor = '#0247FE')
			if("North America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'North America', name = 'North America',fillcolor = '#006A4E')
			if("Asia Pacific" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Asia Pacific', name = 'Asia Pacific',fillcolor = '#FFAA1D')
			if("Australia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Australia', name = 'Australia',fillcolor = '#F19CBB')
			if("Central Asia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Central Asia', name = 'Central Asia',fillcolor = '#A4C639')
			if("Eastern Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Eastern Europe', name = 'Eastern Europe',fillcolor = '#72A0C1')
			if("Middle East" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Middle East', name = 'Middle East',fillcolor = '#00FFFF')
			if("South & Central America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'South & Central America', name = 'South & Central America',fillcolor = '#FDEE00')
			if("Western Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Western Europe', name = 'Western Europe',fillcolor = '#967117')
			if("s2s" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'s2s', name = 's2s',fillcolor = '#B2BEB5')	
		}else{
			data$TOTAL <- apply(data[,!names(data) %in% c("Date")],1,sum)
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
		}
		p <- p %>% add_lines(x= ~fp$Date,y = ~fp$Bcf, name = 'Prior Forecast',color=I('black'),mode = "lines",stackgroup='two',type="scatter",line = list(shape = 'linear', color = 'black', dash = 'dash'))
		
		pl <- layout(p,
			shapes=list(list(type = "line",
                    fillcolor = "blue", line = list(color = "black"), opacity = 1,
                    x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
                    y0 = 0, y1=max_,yref = "Bcf")))
		
	})
		output$import_plot <- renderPlotly({
		data <- dataInput_import()
		
		fp <- dataInput_import_fp()
		fp <- aggregate(Bcf~Date,data=fp,FUN=sum)
		fp <- fp[which(fp$Bcf!=0),]
		
		max_ <- aggregate(Bcf~Date,data=data,FUN=sum)
		max_ <- max(max_$Bcf)
		
		data <- dcast(data[,c("Region","Bcf","Date")],Date~Region,value.var="Bcf",fun.aggregate=sum)
		
		#x= ~data$Date, y= ~data$Africa, name='Africa'
		p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
			layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
		
		if(input$chart_series=="True"){
			if("Africa" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Africa', name = 'Africa',fillcolor = '#0247FE')
			if("North America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'North America', name = 'North America',fillcolor = '#006A4E')
			if("Asia Pacific" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Asia Pacific', name = 'Asia Pacific',fillcolor = '#FFAA1D')
			if("Australia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Australia', name = 'Australia',fillcolor = '#F19CBB')
			if("Central Asia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Central Asia', name = 'Central Asia',fillcolor = '	#A4C639')
			if("Eastern Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Eastern Europe', name = 'Eastern Europe',fillcolor = '#72A0C1')
			if("Middle East" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Middle East', name = 'Middle East',fillcolor = '#00FFFF')
			if("South & Central America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'South & Central America', name = 'South & Central America',fillcolor = '#FDEE00')
			if("Western Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Western Europe', name = 'Western Europe',fillcolor = '#967117')
			if("s2s" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'s2s', name = 's2s',fillcolor = '#B2BEB5')	
		}else{
			data$TOTAL <- apply(data[,!names(data) %in% c("Date")],1,sum)
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
		}
		
		p <- p %>% add_lines(x= ~fp$Date,y = ~fp$Bcf, name = 'Prior Forecast',color=I('black'),mode = "lines",stackgroup='two',type="scatter",fillcolor='tonexty',line = list(shape = 'linear', color = 'tonexty', dash = 'dash'))
		
		pl <- layout(p,
			shapes=list(list(type = "line",
                    fillcolor = "blue", line = list(color = "black"), opacity = 1,
                    x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
                    y0 = 0, y1=max_,yref = "Bcf")))
		
	})
		#count
	output$export_plot_count <- renderPlotly({
		data <- dataInput_export_count()
		
		max_ <- aggregate(Count~Date,data=data,FUN=sum)
		max_ <- max(max_$Count)
		
		data <- dcast(data[,c("Region","Count","Date")],Date~Region,value.var="Count",fun.aggregate=sum)
		
		#fp
		fp <- dataInput_export_count_fp()
		fp <- aggregate(Count~Date,data=fp,FUN=sum)
		fp <- fp[which(fp$Count!=0),]
		
		#x= ~data$Date, y= ~data$Africa, name='Africa'
		p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
			layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
		
		if(input$chart_series=="True"){
			if("Africa" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Africa', name = 'Africa',fillcolor = '#0247FE')
			if("North America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'North America', name = 'North America',fillcolor = '#006A4E')
			if("Asia Pacific" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Asia Pacific', name = 'Asia Pacific',fillcolor = '#FFAA1D')
			if("Australia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Australia', name = 'Australia',fillcolor = '#F19CBB')
			if("Central Asia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Central Asia', name = 'Central Asia',fillcolor = '	#A4C639')
			if("Eastern Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Eastern Europe', name = 'Eastern Europe',fillcolor = '#72A0C1')
			if("Middle East" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Middle East', name = 'Middle East',fillcolor = '#00FFFF')
			if("South & Central America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'South & Central America', name = 'South & Central America',fillcolor = '#FDEE00')
			if("Western Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Western Europe', name = 'Western Europe',fillcolor = '#967117')
			if("s2s" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'s2s', name = 's2s',fillcolor = '#B2BEB5')	
		}else{
			data$TOTAL <- apply(data[,!names(data) %in% c("Date")],1,sum)
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
		}
		
		p <- p %>% add_lines(x= ~fp$Date,y = ~fp$Count, name = 'Prior Forecast',color=I('black'),mode = "lines",stackgroup='two',type="scatter",line = list(shape = 'linear', color = 'black', dash = 'dash'))
		
		pl <- layout(p,
			shapes=list(list(type = "line",
                    fillcolor = "blue", line = list(color = "black"), opacity = 1,
                    x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
                    y0 = 0, y1=max_,yref = "Count")))
		
	})
	
	output$import_plot_count <- renderPlotly({
		data <- dataInput_import_count()
		
		max_ <- aggregate(Count~Date,data=data,FUN=sum)
		max_ <- max(max_$Count)
		
		data <- dcast(data[,c("Region","Count","Date")],Date~Region,value.var="Count",fun.aggregate=sum)
		
		#fp
		fp <- dataInput_import_count_fp()
		fp <- aggregate(Count~Date,data=fp,FUN=sum)
		fp <- fp[which(fp$Count!=0),]
		
		#x= ~data$Date, y= ~data$Africa, name='Africa'
		p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
			layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
		
		if(input$chart_series=="True"){
			if("Africa" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Africa', name = 'Africa',fillcolor = '#0247FE')
			if("North America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'North America', name = 'North America',fillcolor = '#006A4E')
			if("Asia Pacific" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Asia Pacific', name = 'Asia Pacific',fillcolor = '#FFAA1D')
			if("Australia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Australia', name = 'Australia',fillcolor = '#F19CBB')
			if("Central Asia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Central Asia', name = 'Central Asia',fillcolor = '	#A4C639')
			if("Eastern Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Eastern Europe', name = 'Eastern Europe',fillcolor = '#72A0C1')
			if("Middle East" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Middle East', name = 'Middle East',fillcolor = '#00FFFF')
			if("South & Central America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'South & Central America', name = 'South & Central America',fillcolor = '#FDEE00')
			if("Western Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Western Europe', name = 'Western Europe',fillcolor = '#967117')
			if("s2s" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'s2s', name = 's2s',fillcolor = '#B2BEB5')	
		}else{
			data$TOTAL <- apply(data[,!names(data) %in% c("Date")],1,sum)
			p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
		}
		
		p <- p %>% add_lines(x= ~fp$Date,y = ~fp$Count, name = 'Prior Forecast',color=I('black'),mode = "lines",stackgroup='two',type="scatter",line = list(shape = 'linear', color = 'black', dash = 'dash'))
		
		pl <- layout(p,
			shapes=list(list(type = "line",
                    fillcolor = "blue", line = list(color = "black"), opacity = 1,
                    x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
                    y0 = 0, y1=max_,yref = "Count")))
		
	})
}
	
)

