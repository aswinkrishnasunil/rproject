#added forecast progression

library(shiny)
library(ggplot2)
library(lubridate)
library(zoo)
library(grid)
library(gridExtra)
library(plotly)
library(reshape2)
library(RODBC)
library(shinyWidgets)

options(scipen=999)

# Region data
regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
regions$sub_region <- as.character(regions$sub_region)
regions$region <- as.character(regions$region)

shinyApp(
  ui <- fluidPage(
    sidebarLayout(
      sidebarPanel(
        pickerInput(inputId = "region2",label = "Select region",choices = sort(unique(regions$region)),
                    options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
                    multiple = TRUE, selected = sort(unique(regions$region))),
        
        pickerInput(inputId = "sub_region2",label = "Select Sub-Regions",choices = sort(unique(regions$sub_region)),
                    options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
                    multiple = TRUE, selected = sort(unique(regions$sub_region))),
        
        pickerInput(inputId = "region",label = "Include region",choices = sort(unique(regions$region)),
                    options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
                    multiple = TRUE, selected = sort(unique(regions$region))),
        
        pickerInput(inputId = "sub_region",label = "Include Sub-Regions",choices = sort(unique(regions$sub_region)),
                    options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
                    multiple = TRUE, selected = sort(unique(regions$sub_region))),
        
        dateRangeInput("daterng","Select Date Range",Sys.Date()-90,Sys.Date()+30),
        sliderInput("sma","Select Moving Average",1,21,7),
        sliderInput("fp","Select Prior Forecast (Days ago)",1,7,1),
        width=3
      ),
      
      mainPanel(
        tabsetPanel(type="tabs",
                    tabPanel("Chart",
                             div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("bcf_count","Select Units",c("Bcf/d","Ships/d"),inline=T)),
                             div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("chart_series","Graph Series",c("True","False"),inline=T)),
                             textOutput("imports"),
                             uiOutput("import_chart"),
                             textOutput("exports"),
                             uiOutput("export_chart"),
                             textOutput("net"),
                             plotlyOutput("net_chart",height="385"),
                             width=9,
                             tags$head(tags$style("#imports{
						font-size: 15px;
						}#exports{
						font-size: 15px;
						}#net{
						font-size: 15px;
						}")
                             )
                    ),
                    tabPanel("Data",
                             downloadButton("downloadData", "Download"),
                             dataTableOutput("data_table")
                    )
        )
      )
      
    )
  ),
  server <- function(input, output, session) {
    output$imports <- renderText({"Imports"})
    output$exports <- renderText({"Exports"})
    output$net <- renderText({"Net"})
  
    
    regions <- reactive({
      print('Loading regions Data')
      regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
      regions$sub_region <- as.character(regions$sub_region)
      regions$region <- as.character(regions$region)
      print('done')
      
      return(regions)
    })
    
    # Update sub_region drop down
    observeEvent(input$region,{
      regions <- regions()
      
      sub_regions <- regions$sub_region[which(regions$region %in% input$region)]
      updatePickerInput(session = session, inputId = "sub_region",choices = sub_regions, selected = sub_regions)
    })
    
    # Update sub_region2 drop down
    observeEvent(input$region2,{
      regions <- regions()
      
      sub_regions <- regions$sub_region[which(regions$region %in% input$region2)]
      updatePickerInput(session = session, inputId = "sub_region2",choices = sub_regions, selected = sub_regions)
    })
    
    # Last 7 days forecast data
    fp_data <- reactive({
      data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/uo95hdbmzkd9z2zw3skqg/LNG_Region_Flow_Historical_Forecasts.csv?rlkey=i66yrajmnm1ztwheuawj7gpw9&dl=0",header=TRUE)
      data$date <- as.Date(data$date)
      data$region <- as.character(data$region)
      data$subregion <- as.character(data$subregion)
      data$region2 <- as.character(data$region2)
      data$subregion2 <- as.character(data$subregion2)
      
      data[is.na(data)] <- "NULL"
      
      return(data)
    })
    
    #get forecast progression
    fp <- reactive({
      data <- fp_data()
      data <- data[which(data$t==input$fp),]
      
      return(data)
    })
    
    # Get forecas and historical flow data
    dataInput <- reactive({
      data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/er4bopalk1pq0nem2nj37/LNG_flow_L2.csv?rlkey=j8bkrb5zize9a79ld7of552tf&dl=0",header=TRUE)
      data$date <- as.Date(data$date)
      data$region <- as.character(data$region)
      data$subregion <- as.character(data$subregion)
      data$region2 <- as.character(data$region2)
      data$subregion2 <- as.character(data$subregion2)
      
      data[is.na(data)] <- "NULL"
      
      return(data)
    })
    
    # Import chart
    output$import_chart <- renderUI({
      if(input$bcf_count=="Bcf/d"){
        plotlyOutput("import_plot",width="100%",height="385")
      } else {
        plotlyOutput("import_plot_count",width="100%",height="385")
      }
    })
    
    # Export chart
    output$export_chart <- renderUI({
      if(input$bcf_count=="Bcf/d"){
        plotlyOutput("export_plot",width="100%",height="385")
      } else {
        plotlyOutput("export_plot_count",width="100%",height="385")
      }
    })
    
    # Filter data
    dl_data <- reactive({
      data <- dataInput() #dataInput_blend
      data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
      data <- data[which(data$region %in% input$region),]
      data <- data[which(data$subregion %in% input$sub_region),]
      data <- data[which(data$region2 %in% input$region2),]
      data <- data[which(data$subregion2 %in% input$sub_region2),]
      data$gas_volume <- data$gas_volume/1000000
      return(data)
    })
    
    # show data table
    output$data_table <- renderDataTable({
      data <- dl_data()
      return(data)
    })
    
    # data to download
    output$downloadData <- downloadHandler(
      filename = "data.csv",
      content = function(file) {
        write.csv(dl_data(), file,row.names=FALSE)
      }
    )
    
    # FP filtered data
    fp_filtered <- reactive({
      data <- fp() #dataInput_blend
      data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
      data <- data[which(data$region %in% input$region),]
      data <- data[which(data$subregion %in% input$sub_region),]
      data <- data[which(data$region2 %in% input$region2),]
      data <- data[which(data$subregion2 %in% input$sub_region2),]
      data$gas_volume <- data$gas_volume/1000000
      return(data)
    })
    
    
    # gas_capacity
    gs_data <- reactive({
      data <- dl_data()
      data_fp <- fp_filtered()
      
      # bcf
      data_ag <- aggregate(gas_volume~date+region+type, data=data, FUN=sum)
      data_temp <- aggregate(gas_volume~date+region+type, data=data_fp, FUN=sum)
      
      # imo count
      data_ag_t <- aggregate(imo~date+region+type, data=data, FUN=length)
      data_temp_t <- aggregate(imo~date+region+type, data=data_fp, FUN=length)
      
      data_ag <- merge(data_ag, data_ag_t, by = c("date", "region", "type"), all = TRUE)
      data_fp <- merge(data_temp, data_temp_t, by = c("date", "region", "type"), all = TRUE)
      
      list(data_ag = data_ag, data_fp = data_fp)
    })
    
    
    # imo count
    # imo_count_data <- reactive({
    #   data <- dl_data()
    #   data_ag <- aggregate(imo~date+region+type, data=data, FUN=length)
    #   data_fp <- fp_filtered()
    #   data_fp <- aggregate(imo~date+region+type, data=data_fp, FUN=length)
    #   
    #   list(data_ag = data_ag, data_fp = data_fp)
    # })
    
    # final data bcf/imo count
    final_data <- reactive({
      result <- gs_data()
      data_ag <- result$data_ag
      data_fp <- result$data_fp
      
      data_ag_import <- data_ag[which(data_ag$type == 'Import')]
      data_ag_export <- data_ag[which(data_ag$type == 'Export')]
      data_fp_import <- data_fp[which(data_fp$type == 'Import')]
      data_fp_export <- data_fp[which(data_fp$type == 'Export')]
      
      #calc Moving Average Import
      data2 <- data.frame(matrix(nrow=0,ncol=4))
      region <- as.character(unique(data_ag_import$region))
      region <- region[!is.na(region)]
      for(i in 1:length(region)){
        temp <- data_ag_import[which(data_ag_import$region==region[i]),]
        
        if(nrow(temp)>0){
          temp$gas_volume_mv <- rollmean(temp$gas_volume,input$sma,na.pad=T,align="right")
          temp$imo_mv <- rollmean(temp$imo,input$sma,na.pad=T,align="right")
          
          data2 <- rbind(data2,temp)
        }
      }
      
      data2$gas_volume_mv[which(is.na(data2$gas_volume_mv))] <- 0
      data2$imo_mv[which(is.na(data2$imo_mv))] <- 0
      data2 <- data2[order(data2$region,data2$date),]
      data_ag_import <- data2
      
      #calc Moving Average Export
      data2 <- data.frame(matrix(nrow=0,ncol=4))
      region <- as.character(unique(data_ag_export$region))
      region <- region[!is.na(region)]
      for(i in 1:length(region)){
        temp <- data_ag_export[which(data_ag_export$region==region[i]),]
        
        if(nrow(temp)>0){
          temp$gas_volume_mv <- rollmean(temp$gas_volume,input$sma,na.pad=T,align="right")
          temp$imo_mv <- rollmean(temp$imo,input$sma,na.pad=T,align="right")
          
          data2 <- rbind(data2,temp)
        }
      }
      
      data2$gas_volume_mv[which(is.na(data2$gas_volume_mv))] <- 0
      data2$imo_mv[which(is.na(data2$imo_mv))] <- 0
      data2 <- data2[order(data2$region,data2$date),]
      data_ag_export <- data2
      
      #calc Moving Average Import
      data2 <- data.frame(matrix(nrow=0,ncol=4))
      region <- as.character(unique(data_fp_import$region))
      region <- region[!is.na(region)]
      for(i in 1:length(region)){
        temp <- data_fp_import[which(data_fp_import$region==region[i]),]
        
        if(nrow(temp)>0){
          temp$gas_volume_mv <- rollmean(temp$gas_volume,input$sma,na.pad=T,align="right")
          temp$imo_mv <- rollmean(temp$imo,input$sma,na.pad=T,align="right")
          
          data2 <- rbind(data2,temp)
        }
      }
      
      data2$gas_volume_mv[which(is.na(data2$gas_volume_mv))] <- 0
      data2$imo_mv[which(is.na(data2$imo_mv))] <- 0
      data2 <- data2[order(data2$region,data2$date),]
      data_fp_import <- data2
      
      #calc Moving Average Export
      data2 <- data.frame(matrix(nrow=0,ncol=4))
      region <- as.character(unique(data_fp_export$region))
      region <- region[!is.na(region)]
      for(i in 1:length(region)){
        temp <- data_fp_export[which(data_fp_export$region==region[i]),]
        
        if(nrow(temp)>0){
          temp$gas_volume_mv <- rollmean(temp$gas_volume,input$sma,na.pad=T,align="right")
          temp$imo_mv <- rollmean(temp$imo,input$sma,na.pad=T,align="right")
          
          data2 <- rbind(data2,temp)
        }
      }
      
      data2$gas_volume_mv[which(is.na(data2$gas_volume_mv))] <- 0
      data2$imo_mv[which(is.na(data2$imo_mv))] <- 0
      data2 <- data2[order(data2$region,data2$date),]
      data_fp_export <- data2
      
      list(data_ag_import = data_ag_import, data_ag_export = data_ag_export,
           data_fp_import = data_fp_import, data_fp_export = data_fp_export)
      
    })
    
    
    # plot export output
    output$export_plot <- renderPlotly({
      result <- final_data()
      data_ag_export = result$data_ag_export
      data_fp_export = result$data_fp_export
      
      # fp <- dataInput_export_fp()
      # fp <- aggregate(Bcf~Date,data=fp,FUN=sum)
      # fp <- fp[which(fp$Bcf!=0),]
      # 
      # max_ <- aggregate(Bcf~Date,data=data,FUN=sum)
      
      # data <- dcast(data[,c("Region","Bcf","Date")],Date~Region,value.var="Bcf",fun.aggregate=sum)
      if(input$bcf_count=="Bcf/d"){
        data <- data_ag_export[, c("Region", "gas_volume_mv", "Date")]
        names(data) <- c("Region","Bcf","Date")
      } else {
        data <- data_ag_export[, c("Region", "imo_mv", "Date")]
        names(data) <- c("Region","Bcf","Date")
      }
      
      max_ <- max(data$Bcf)
      
      p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
        layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')	
      
      if(input$chart_series=="True"){
        if("Africa" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Africa', name = 'Africa',fillcolor = '#0247FE')
        if("North America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'North America', name = 'North America',fillcolor = '#006A4E')
        if("Asia Pacific" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Asia Pacific', name = 'Asia Pacific',fillcolor = '#FFAA1D')
        if("Australia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Australia', name = 'Australia',fillcolor = '#F19CBB')
        if("Central Asia" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Central Asia', name = 'Central Asia',fillcolor = '#A4C639')
        if("Eastern Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Eastern Europe', name = 'Eastern Europe',fillcolor = '#72A0C1')
        if("Middle East" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Middle East', name = 'Middle East',fillcolor = '#00FFFF')
        if("South & Central America" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'South & Central America', name = 'South & Central America',fillcolor = '#FDEE00')
        if("Western Europe" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'Western Europe', name = 'Western Europe',fillcolor = '#967117')
        if("s2s" %in% names(data)) p <- p %>% add_trace(x= ~data$Date,y = ~data$'s2s', name = 's2s',fillcolor = '#B2BEB5')	
      }else{
        data$TOTAL <- apply(data[,!names(data) %in% c("Date")],1,sum)
        p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
      }
      p <- p %>% add_lines(x= ~fp$Date,y = ~fp$Bcf, name = 'Prior Forecast',color=I('black'),mode = "lines",stackgroup='two',type="scatter",line = list(shape = 'linear', color = 'black', dash = 'dash'))
      
      pl <- layout(p,
                   shapes=list(list(type = "line",
                                    fillcolor = "blue", line = list(color = "black"), opacity = 1,
                                    x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
                                    y0 = 0, y1=max_,yref = "Bcf")))
      
    })
    
    
    
    
    
    # 
    # output$net_chart <- renderPlotly({
    #   if(input$bcf_count=="Bcf/d"){ #Bcf
    #     exports <- dataInput_export()
    #     exports$Bcf <- exports$Bcf * -1
    #     imports <- dataInput_import()
    #     
    #     data <- rbind(exports,imports)
    #     
    #     #data$Date <- data$date
    #     #data$Bcf <- data$gas_volume/1000000
    #     
    #     max_ <- aggregate(Bcf~Date,data=data,FUN=sum)
    #     data <- max_
    #     max_ <- max(data$Bcf)
    #     min_ <- min(0,data$Bcf)
    #     
    #     p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
    #       layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
    #     
    #     data$TOTAL <- data$Bcf
    #     p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
    #     
    #     pl <- layout(p,
    #                  shapes=list(list(type = "line",
    #                                   fillcolor = "blue", line = list(color = "black"), opacity = 1,
    #                                   x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
    #                                   y0 =min_, y1=max_,yref = "Bcf")))
    #   } else { #Count
    #     exports <- dataInput_export_count()
    #     exports$Count <- exports$Count * -1
    #     imports <- dataInput_import_count()
    #     
    #     
    #     
    #     data <- rbind(exports,imports)
    #     
    #     max_ <- aggregate(Count~Date,data=data,FUN=sum)
    #     data <- max_
    #     max_ <- max(data$Count)
    #     min_ <- min(0,data$Count)
    #     
    #     p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
    #       layout(legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
    #     
    #     data$TOTAL <- data$Count
    #     p <- p %>% add_trace(x= ~data$Date,y = ~data$TOTAL, name = 'Total',fillcolor = '#B2BEB5')	
    #     
    #     
    #     
    #     pl <- layout(p,
    #                  shapes=list(list(type = "line",
    #                                   fillcolor = "blue", line = list(color = "black"), opacity = 1,
    #                                   x0 = Sys.Date(), x1 = Sys.Date(), xref = "Date",
    #                                   y0 =min_, y1=max_,yref = "Count")))
    #   }
    # })
    
    
    }   
)
    