#shiny::runApp("J:/_Eric Anderson/NG Analysis/LNG/Ocean Regions/Ocean Regions Shiny App")

library(shiny)
library(plotly)
library(zoo)

shinyApp(
ui <- fluidPage(
	sidebarLayout(
		sidebarPanel(
			dateRangeInput("daterng","Select Date Range",Sys.Date()-365,Sys.Date()),
			checkboxInput("breakout","Breakout",TRUE),
			uiOutput("botf"),
			sliderInput("sma","Select Moving Average",1,21,14),
			div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("bcf_count","Select Units",c("Ships","Bcf"),inline=T)),
			checkboxGroupInput("chart_display","Display Graphs", c("Atlantic","Indian Ocean","Pacific","Total"),c("Atlantic","Indian Ocean","Pacific","Total")),
			img(src="World Map.PNG",width="100%", height="100%"),
			width=4
		),
		
		mainPanel(
			
			conditionalPanel(
				condition= "input.chart_display.includes('Atlantic')",
				textOutput("region1"),
				plotlyOutput("plot1",height="300")
			),
			conditionalPanel(
				condition= "input.chart_display.includes('Indian Ocean')",
				textOutput("region3"),
				plotlyOutput("plot3",height="300")
			),
			conditionalPanel(
				condition= "input.chart_display.includes('Pacific')",
				textOutput("region4"),
				plotlyOutput("plot4",height="300")
			),
			conditionalPanel(
				condition= "input.chart_display.includes('Total')",
				textOutput("all"),
				plotlyOutput("plot_all",height="300")
			),
			tags$head(tags$style("#region1{
				font-size: 15px;
				font-style: bold;
				}#region2{
				font-size: 15px;
				font-style: bold;
				}#region3{
				font-size: 15px;
				font-style: bold;
				}#region4{
				font-size: 15px;
				font-style: bold;
				}#all{
				font-size: 15px;
				font-style: bold;
				}")),
			width=8
		)

	)
),
server <- function(input, output, session) {
	#get data
	dataInput <- reactive({
		if(input$bcf_count == "Ships"){
			data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/tylwof0qjrmrr01cs8oi2/Ocean_Regions.csv?rlkey=nmkbs2aj1upxzxue7f3p4rsl0&dl=0",check.names=F)
		} else {
			data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/nr6gan4md2k4nc6m9kh3c/Ocean_Regions_Bcf.csv?rlkey=ywopoidbon1bkwulk89cp2tz5&dl=0", check.names=F)
		}
		data$date <- as.Date(data$date)
		
		#make one = one + two
		data$f1 <- data$f1 + data$f2
		data$e1 <- data$e1 + data$e2
		data$f2 <- 0
		data$e2 <- 0
		
		data$one <- data$f1 + data$e1
		data$two <- data$f2 + data$e2
		data$three <- data$f3 + data$e3
		data$four <- data$f4 + data$e4
		
		data$e <- data$e1 + data$e2 + data$e3 + data$e4
		data$f <- data$f1 + data$f2 + data$f3 + data$f4
		
		data$all = data$e + data$f
		
		return(data)
	})
	
	dataDtrng <- reactive({
		data <- dataInput()
		
		#sma
		data[,-1] <- apply(data[,-1],2,function(x){rollmean(x,input$sma,na.pad=T,align="right")})
		data <- data[complete.cases(data),]
		
		#date range
		data <- data[which(data$date %in% seq(input$daterng[1],input$daterng[2],"day")),]
		
		return(data)
	})

	#text
	output$br <- renderText({"Breakout Empty & Full"})
	output$region1 <- renderText({"Atlantic"})
	output$region2 <- renderText({"Atlantic South"})
	output$region3 <- renderText({"Indian Ocean"})
	output$region4 <- renderText({"Pacific"})
	output$all <- renderText({"Total"})
	
	#plots
	output$botf <- renderUI({
		if(input$breakout){
			checkboxGroupInput("ef_series","",c("Full","Empty"),c("Full","Empty"),inline=T)
		}else{
			return(NULL)
		}
	})
	
	output$plot1 <- renderPlotly({
		data <- dataDtrng()
		
		if(input$breakout==T){
			p <- plot_ly(type = 'scatter', mode = 'lines') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$e1, name = 'Empty',line = list(color='orange'))
			if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$f1, name = 'Full',line = list(color='blue'))
		} else {
			p <- plot_ly(data,x=~date,y= ~one, name="Full", type = 'scatter', mode = 'lines',line = list(color='black')) %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
		}
		
		p
	})
	
	output$plot2 <- renderPlotly({
		data <- dataDtrng()
		
		if(input$breakout==T){
			p <- plot_ly(type = 'scatter', mode = 'lines') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$e2, name = 'Empty',line = list(color='orange'))
			if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$f2, name = 'Full',line = list(color='blue'))
			
			p
		} else {
			p <- plot_ly(data,x=~date,y= ~two, name="Full", type = 'scatter', mode = 'lines',line = list(color='black')) %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			p
		}
	})
	
	output$plot3 <- renderPlotly({
		data <- dataDtrng()
		
		if(input$breakout==T){
			p <- plot_ly(type = 'scatter', mode = 'lines') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$e3, name = 'Empty',line = list(color='orange'))
			if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$f3, name = 'Full',line = list(color='blue'))
			
			p
		} else {
			p <- plot_ly(data,x=~date,y= ~three, name="Full", type = 'scatter', mode = 'lines',line = list(color='black')) %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			p
		}
	})
	
	output$plot4 <- renderPlotly({
		data <- dataDtrng()
		
		if(input$breakout==T){
			p <- plot_ly(type = 'scatter', mode = 'lines') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$e4, name = 'Empty',line = list(color='orange'))
			if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$f4, name = 'Full',line = list(color='blue'))
			
			p
		} else {
			p <- plot_ly(data,x=~date,y= ~four, name="Full", type = 'scatter', mode = 'lines',line = list(color='black')) %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			p
		}
	})
	
	output$plot_all <- renderPlotly({
		data <- dataDtrng()
		
		if(input$breakout==T){
			p <- plot_ly(type = 'scatter', mode = 'lines') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$e, name = 'Empty',line = list(color='orange'))
			if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date,y = ~data$f, name = 'Full',line = list(color='blue'))
			
			p
		} else {
			p <- plot_ly(data,x=~date,y= ~all, name="Full", type = 'scatter', mode = 'lines',line = list(color='black')) %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
			
			p
		}
	})
}
)
