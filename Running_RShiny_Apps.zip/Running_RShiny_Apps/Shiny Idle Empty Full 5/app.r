#shiny::runApp("J:/_Eric Anderson/NG Analysis/LNG/Shiny Idle Empty Full 4")

# VERSION 5

# changes in v4:
# -added sub_regions
# -improved file compression

#in v5 switched to importing data from rdata files

library(shiny)
library(plotly)
library(zoo)

# region lookup table, must be up to date, not dynamic
region_cat <- data.frame(region=c("North America","Asia Pacific","Western Europe","South & Central America","Asia Pacific","Western Europe",
	"Western Europe","North America","Western Europe","Asia Pacific","Asia Pacific","Central Asia","Eastern Europe","South & Central America",
	"Australia","Africa","Western Europe","Middle East","South & Central America","Africa","Asia Pacific","North America","Middle East","North America",
	"North America","North America","Eastern Europe", "Africa", "Eastern Europe", "s2s"),
	sub_region = c("US East Coast","China","Northwest Europe","North SA","South Korea","Italy","UK","Caribbean","Iberian Europe",
		"Southeast Asia","Japan","Central Asia","Southeast Europe","East SA","Australia","North Africa","Scandinavia","Gulf of Oman",
		"West SA","West Africa","South Russia","MX Gulf Coast","Suez","US West Coast","Mexico Pacific","US Gulf Coast","North Russia",
		"East Africa", "West Russia", "s2s"))
region_cat$region <- as.character(region_cat$region)
region_cat$sub_region <- as.character(region_cat$sub_region)

shinyApp(
ui <- fluidPage(
	sidebarLayout(
		sidebarPanel(
			dateRangeInput("daterng","Select Date Range",Sys.Date()-270,Sys.Date()+14),
			sliderInput("sma","Select Moving Average",1,21,1),
			sliderInput("idle_days","If Idle For More Than (Days)",1,5,2),
			checkboxGroupInput("region","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s")),
			actionLink("selectall","Select/Unselect All"),
			checkboxGroupInput("sub_region","Include Sub-Regions",
				choices=c(region_cat$sub_region),selected=c(region_cat$sub_region)),
			width=3
		),
		
		mainPanel(
			div(style="display: inline-block;vertical-align:top; width: 150px;",radioButtons("bcf_count","Select Units",c("Bcf","Ships"),inline=T)),
			textOutput("ia"),
			plotlyOutput("plot_ia"),
			div(style="display: inline-block;vertical-align:top; width: 150px;",checkboxInput("breakout","Breakout",TRUE)),
			div(style="display: inline-block;vertical-align:top; width: 150px;",uiOutput("botf")),
			textOutput("ef"),
			plotlyOutput("plot_ef"),
			tags$head(tags$style("#ia{
				font-size: 20px;
				}#ef{
				font-size: 20px;
				}")
				),
				width=9
		)

	)
),
server <- function(input, output, session) {
	#update sub_region checkboxes
	observe({
		updateCheckboxGroupInput(session,"sub_region",choices=c(region_cat$sub_region[which(region_cat$region %in% input$region)]),
			selected=c(region_cat$sub_region[which(region_cat$region %in% input$region)]))
	})

	observe({
		if(input$selectall == 0) return(NULL) 
		else if (input$selectall%%2 == 0){
			updateCheckboxGroupInput(session,"region","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		}else{
			updateCheckboxGroupInput(session,"region","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		}
	})

	output$ia <- renderText({"Idle"})
	output$ef <- renderText({"Empty v Full"})
	
	output$botf <- renderUI({
		if(input$breakout){
			checkboxGroupInput("ef_series","",c("Full","Empty"),c("Full","Empty"),inline=T)
		}else{
			return(NULL)
		}
	})

	dataInput <- reactive({
		#get compressed data
		#load(url("https://www.dropbox.com/s/5okvq5jtj60w84h/empty_full_idle5.RData?dl=1"))
	  data <- read.csv(url("https://dl.dropboxusercontent.com/scl/fi/4fto81gy2m0tvaxb70akv/empty_full_idle5.csv?rlkey=svlaxafjepprydpv2fsau6oth&dl=0"))
		
		#formating
		data$date_ <- as.Date(data$date_)
		
		return(data)
	})
	
	#filters
	dataDtrng <- reactive({
		data <- dataInput()
		
		#date range
		data <- data[which(data$date_ %in% seq(input$daterng[1],input$daterng[2],"day")),]
		
		#region
		data <- data[which(data$sub_region %in% input$sub_region),]
		
		return(data)
	})
	
	dataIA <- reactive({
		data <- dataDtrng()
		data$idle <- 0
		data$idle[which(data$idle_days >= as.numeric(input$idle_days))] <- 1
		
		data$idle_empty <- 0
		data$idle_full <- 0
		data$idle_empty[which(data$idle==1 & data$empty==0)] <- 1
		data$idle_full[which(data$idle==1 & data$empty==1)] <- 1
		
		if(input$bcf_count=="Ships"){
			data_ <- aggregate(cbind(idle,idle_empty,idle_full) ~ date_,data=data,FUN=sum)
		}else{
			data_ <- data[which(data$idle==1),]
			data_$idle <- data_$idle * data_$bcf_cap
			data_$idle_empty <- data_$idle_empty * data_$bcf_cap
			data_$idle_full <- data_$idle_full * data_$bcf_cap
			data_ <- aggregate(cbind(idle,idle_empty,idle_full) ~ date_,data=data_,FUN=sum)
		}
		data_$idle <- rollmean(data_$idle,input$sma,na.pad=T,align="right")
		data_$idle_empty <- rollmean(data_$idle_empty,input$sma,na.pad=T,align="right")
		data_$idle_full <- rollmean(data_$idle_full,input$sma,na.pad=T,align="right")
		return(data_)
	})
	
	dataEF <- reactive({
		data <- dataDtrng()
		
		
		
		data$full <- ifelse(data$empty_full==1,1,0)
		data$empty <- ifelse(data$empty_full==1,0,1)
		
		if(input$bcf_count=="Bcf"){
			data$full <- data$full * data$bcf_cap
			data$empty <- data$empty * data$bcf_cap
		}
		
		data_ <- aggregate(cbind(full,empty) ~ date_,data=data,FUN=sum)
		data_$full <- rollmean(data_$full,input$sma,na.pad=T,align="right")
		data_$empty <- rollmean(data_$empty,input$sma,na.pad=T,align="right")
		return(data_)
	})
	
	output$plot_ia <- renderPlotly({
		data <- dataIA()
		
		if(input$breakout){
			p <- plot_ly(type = 'scatter', mode = 'none', stackgroup = 'one') %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count),legend = list(orientation = 'h'), xaxis = list(title="",showticklabels=TRUE), yaxis = list(title=""),hovermode = 'compare')
				if("Empty" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date_,y = ~data$idle_empty, name = 'Empty',fillcolor = 'orange')
				if("Full" %in% input$ef_series) p <- p %>% add_trace(x= ~data$date_,y = ~data$idle_full, name = 'Full',fillcolor = 'blue')
			p
		}else{
			p <- plot_ly(data,x=~date_,y= ~idle, name="Idle", type = 'scatter', mode = 'lines') %>%
				layout(legend = list(orientation = 'h')) %>%
				layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
		}
	})
	output$plot_ef <- renderPlotly({
		data <- dataEF()
		
		p <- plot_ly(data,x=~date_,y= ~full, name="Full", type = 'scatter', mode = 'lines') %>%
			add_trace(y=~empty,name="Empty",mode="lines") %>%
			layout(legend = list(orientation = 'h')) %>%
			layout(xaxis=list(title="Date"),yaxis=list(title=input$bcf_count))
	})
}
)
