library(shiny)
library(leaflet)
library(htmlwidgets)
library(sf)
library(mapview)
library(leaflet.extras)
library(mapedit)
library(webshot)


ports <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4h83p47fpaz5v1tnhaw69/ports.csv?rlkey=1erpymfq8eq6fzst5dcxi0wt3&dl=0",header=TRUE)

terminalIcons <-   icons(
  iconUrl = ifelse(ports$category == "Import",
                   "import.png",
                   "export.png"
  ),
  iconWidth = 17, iconHeight = 23,
  iconAnchorX = 9, iconAnchorY = 13,
)

mymap <- leaflet() %>%
  clearShapes() %>%
  clearMarkers() %>%
  clearControls() %>%
  addTiles() %>% 
  addMarkers(icon=terminalIcons,lat=ports$lat,lng=ports$lon,label=lapply(paste0("Name: ",ports$name,"<br/>",
                                                                              "Type: ",ports$category,"<br/>",
                                                                              "Country: ",ports$country,"<br/>"),HTML))


saveWidget(mymap, file = "my_custom_map.html")
st_write(obj = mymap, dsn = "my_custom_map.html", driver = "libkml")
