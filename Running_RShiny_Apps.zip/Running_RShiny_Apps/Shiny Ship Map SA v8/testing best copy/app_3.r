#shiny::runApp("J:/_Eric Anderson/NG Analysis/LNG/Shiny Ship Map SA v6")
# Built from Shiny Ship Map SA, in v4 added subregion checkbox dropdown
# in v5 added y/y diff for ship counter
# in v6 added max full draft filter
# in v6 switched to RData files(compressed/faster)
# ____

library(shiny)
library(leaflet)
library(sp)
library(geosphere)
library(lubridate)
library(rdrop2)
library(shinyWidgets)

regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
regions$sub_region <- as.character(regions$sub_region)
regions$region <- as.character(regions$region)

ports <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4h83p47fpaz5v1tnhaw69/ports.csv?rlkey=1erpymfq8eq6fzst5dcxi0wt3&dl=0",header=TRUE)
shinyApp(
ui <- bootstrapPage(
	tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
	leafletOutput("mymap", width = "100%", height = "100%"),
	absolutePanel(top = 10, right = 10,
		wellPanel(
		  style = "width: 300px;",
			sliderInput(inputId="hourInput",label="Ship Path Length (hours)",
			step=6,value=72,min=7,max=72),
			pickerInput("dest_cb", "Include Dest Regions",
			            choices = sort(unique(regions$region)),
			            options = list(`actions-box` = TRUE, size = 10, `selected-text-format` = "count > 3", `live-search` = TRUE),
			            multiple = TRUE,selected = sort(unique(regions$region))),
			pickerInput(inputId = "SubRegion",label = "Select Sub-Regions",choices = sort(unique(regions$sub_region)),
			            options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
			            multiple = TRUE, selected = sort(unique(regions$sub_region))),
			pickerInput(inputId = "ports",label = "Select Ports",choices = sort(unique(ports$name)),
			            options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE),
			            multiple = TRUE, selected = sort(unique(ports$name))),
			checkboxGroupInput("idle_cb","Idle Ships",c("Idle","Active"),c("Idle","Active"), inline = TRUE),
			checkboxGroupInput("ef_cb","Empty Full",c("Empty","Full"),c("Empty","Full"), inline = TRUE),
			sliderInput("idle_days","Idle If No Movement In (Days)",1,5,5),
			sliderInput("max_draft","Max Full Draft (Meters)",11,14,14, step=0.25),
			htmlOutput("ship_count")
		)
	),
	
	absolutePanel(top = 10, left = 50,
	              wellPanel(
	                style = "width: 220px;",
	                searchInput("imo_search", "Search IMO:", placeholder = "Enter IMO", btnReset = icon("xmark"),
	                            btnSearch = icon("magnifying-glass"), width = "170px"),
	                # numericInput("num", "text not allowed", min=1111111, max = 9999999, value=1),
	                pickerInput("source_cb", "Include Origin Regions",
	                            choices = sort(unique(regions$region)),
	                            options = list(`actions-box` = TRUE, size = 10, `selected-text-format` = "count > 3", `live-search` = TRUE, width = "170px"),
	                            multiple = TRUE, selected = sort(unique(regions$region))),
	                pickerInput(inputId = "sourceSubRegion",label = "Select Sub-Regions",choices = sort(unique(regions$sub_region)),
	                            options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE, width = "170px"),
	                            multiple = TRUE, selected = sort(unique(regions$sub_region))),
	                pickerInput(inputId = "sourceports",label = "Select Ports",choices = sort(unique(ports$name)),
	                            options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3", `live-search` = TRUE, width = "170px"),
	                            multiple = TRUE, selected = sort(unique(ports$name)),htmlOutput("leftpane")),
	                ),),),
# Add JavaScript code to reset filters when IMO is searched

server <- function(input, output, session) {
	ship_data <- reactive({
	  print('loading ship data')
	  data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4bz3qrjqhbevtlqn4w131/imo_tracking.csv?rlkey=w9evtnyx2oo1wwx2sdaw0190r&dl=0")
		print('done')
		# data <- merge(tracking, imo, by="imo", x.all=T)
		
		data$date <- as.Date(data$seen_date)
		data <- data[which(data$imo %in% unique(data$imo)),c("date","lat","lon","imo","seen_date",
			"name","imo","draft","empty_draft","sog","stated_destination","model_dest","source_region","source_subregion","prob","stated_eta","d2d","model_eta","size","bcf_cap",
			"origin_name","origin_type","sub_region","idle","gas_cap","dwt", "max_draft", "pr_port", "port_prob", "port_eta")]
		data <- data[complete.cases(data[,c("lat","lon","imo","seen_date")]),]
		data$seen_date <- strptime(data$seen_date,format="%Y-%m-%d %H:%M:%S")
		data <- data[order(data$seen_date),]
		return(data)
	})
	
	port_data <- reactive({
	  print('Loading Port Data')
		ports <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4h83p47fpaz5v1tnhaw69/ports.csv?rlkey=1erpymfq8eq6fzst5dcxi0wt3&dl=0",header=TRUE)
		print('done')
		return(ports)
	})
	
	regions <- reactive({
	  print('Loading regions Data')
		regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
		regions$sub_region <- as.character(regions$sub_region)
		regions$region <- as.character(regions$region)
		print('done')
		
		return(regions)
	})
	
	yy_ship_count <- reactive({
	  print('Loading yy ship count')
		data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/gzu9k87fxiutcf0q6uqo3/yy_ship_count.csv?rlkey=04hv0trgaoe0myk3pjcsmnu7e&dl=0",header=TRUE)
		print('done')
		return(data)
	})
	
	yy_ship_count_filter <- reactive({
		data <- yy_ship_count()
		
		#regions
		data <- data[which(data$region %in% input$dest_cb),]
		
		#subregions
		filtered_data <- data[which(data$subregion %in% input$SubRegion),]
		
		# ports
		filtered_data <- filtered_data[which(filtered_data$port_name %in% input$ports),]
		
		if(nrow(filtered_data) > 0){ #do not allow empty sub_region to be passed for filter
			data <- filtered_data
		}
		
		#idle
		if(length(input$idle_cb)==1){
			if(input$idle_cb == "Idle"){
				data <- data[which(data$idle == 1),]
			}else{
				data <- data[which(data$idle == 0),]
			}
		}
		
		#empty_full
		if(length(input$ef_cb)==1){
			if(input$ef_cb == "Empty"){
				data <- data[which(data$empty_full == 0),]
			}else{
				data <- data[which(data$empty_full == 1),]
			}
		}
		
		return(data)
	})
# 	
# 	observeEvent(input$imo_search, {
# 	  imo_to_search <- input$imo_search
# 	  ship_data_value <- ship_data()  # Use ship_data as a function to get its value
# 	  regions <- regions()
# 	  ports <- port_data()
# 	  #browser()
# 	  if (!is.null(imo_to_search) && imo_to_search %in% ship_data_value$imo) {
# 	    # Get the latest location of the IMO
# 	    
# 	    imo_data <- subset(ship_data_value, origin_name %in% input$sourceports & pr_port %in% input$ports)
# 	    
# 	    if (!imo_to_search %in% imo_data$imo){
# 	    updateSliderInput(session = session, inputId ="hourInput", value = 72);
# 	    updatePickerInput(session = session, inputId ="dest_cb", choices = sort(unique(regions$region)), selected = sort(unique(regions$region)));
# 	    updatePickerInput(session = session, inputId ="SubRegion", choices = sort(unique(regions$sub_region)), selected = sort(unique(regions$sub_region)));
# 	    updatePickerInput(session = session, inputId ="ports", choices = sort(unique(ports$name)), selected = sort(unique(ports$name)));
# 	    updatePickerInput(session = session, inputId ="source_cb", choices = sort(unique(regions$region)), selected = sort(unique(regions$region)));
# 	    updatePickerInput(session = session, inputId ="sourceSubRegion", choices = sort(unique(regions$sub_region)), selected = sort(unique(regions$sub_region)));
# 	    updatePickerInput(session = session, inputId ="sourceports", choices = sort(unique(ports$name)), selected = sort(unique(ports$name)));
# 	    updateCheckboxGroupInput(session = session, inputId ="idle_cb", selected = c("Idle", "Active"));
# 	    updateCheckboxGroupInput(session = session,inputId = "ef_cb", selected = c("Empty", "Full"));
# 	    updateSliderInput(session = session, inputId ="idle_days", value = 5);
# 	    updateSliderInput(session = session, inputId ="max_draft", value = 14);
#       imo_location <- ship_data_value[ship_data_value$imo == imo_to_search, c("lat", "lon", "seen_date")];
#       imo_location <- imo_location[which(imo_location$seen_date == max(imo_location$seen_date)), c("lat", "lon")];
#       leafletProxy("mymap") %>%
#         setView(lng = imo_location$lon, lat = imo_location$lat, zoom = 10)
# 	    }else {
# 	    imo_location <- ship_data_value[ship_data_value$imo == imo_to_search, c("lat", "lon", "seen_date")];
# 	    
# 	    # Select the row with the max seen_date
# 	    imo_location <- imo_location[which(imo_location$seen_date == max(imo_location$seen_date)), c("lat", "lon")];
# 	    leafletProxy("mymap") %>%
# 	      setView(lng = imo_location$lon, lat = imo_location$lat, zoom = 10)}
# 	   
# 	  }
# 	})
# 	
	
	#update subregion picker when checkboxes updated
	observeEvent(input$dest_cb,{
		regions <- regions()
		
		sub_regions <- regions$sub_region[which(regions$region %in% input$dest_cb)]
		updatePickerInput(session = session, inputId = "SubRegion",
		                  choices = sort(unique(sub_regions)), 
		                  selected = sort(unique(sub_regions)))
	})
	
	# Update ports picker when subregion updated
	observeEvent(input$SubRegion,{
	  ports_data <- port_data()
	  
	  ports_selected <- unique(ports_data$name[which(ports_data$sub_region2 %in% input$SubRegion)])
	  updatePickerInput(session = session, inputId = "ports",
	                    choices = sort(unique(ports_selected)), 
	                    selected = sort(unique(ports_selected)))
	})

	#update sourcesubregion picker when checkboxes updated
	observeEvent(input$source_cb,{
	  regions <- regions()
	  
	  sub_regions <- regions$sub_region[which(regions$region %in% input$source_cb)]
	  updatePickerInput(session = session, inputId = "sourceSubRegion",choices = sub_regions, selected = sub_regions)
	})

	# Update origin ports picker when subregion updated
	observeEvent(input$sourceSubRegion,{
	  ports_data <- port_data()
	  
	  ports_selected <- unique(ports_data$name[which(ports_data$sub_region2 %in% input$sourceSubRegion)])
	  updatePickerInput(session = session, inputId = "sourceports",
	                    choices = sort(unique(ports_selected)), 
	                    selected = sort(unique(ports_selected)))
	})
	
	data_filter <- reactive({
		print("data_filter")
		data <- ship_data()

		#add orgin_country
		ports <- port_data()
		
		if (!is.null(input$imo_search)) {
		  imo_to_process <- as.numeric(input$imo_search)
		  
		  if (!is.na(imo_to_process) && is.numeric(imo_to_process)) {
		    if (imo_to_process > 1111111) {
		      imo_in_search <- imo_to_process
		    } else {
		      imo_in_search <- NULL
		    }
		  } else {
		    imo_in_search <- NULL
		  }
		} else {
		  imo_in_search <- NULL
		}
		
		data$origin_country <- ports$country[match(data$origin_name,ports$name)]
		# Check if IMO search is not empty
		if (!is.null(imo_in_search) && imo_in_search %in% data$imo) {
		  # If IMO is found, filter the data to include only that IMO
		  data <- data[data$imo == input$imo_search, ]
		  imo_location <- data[, c("lat", "lon", "seen_date")]
 	    imo_location <- imo_location[which(imo_location$seen_date == max(imo_location$seen_date)), c("lat", "lon")]
 	    leafletProxy("mymap") %>%
 	      setView(lng = imo_location$lon, lat = imo_location$lat, zoom = 10)
		} else {
		  
		  if(is.na(imo_to_process)){
		    
		    #print(imo_to_process)
  		# Region filter
  		if (length(input$source_cb) > 0 && length(input$dest_cb) > 0 ) {
  		  data <- subset(data, source_region %in% input$source_cb & model_dest %in% input$dest_cb)
  		}
  		
  		# SubRegion filter
  		if (length(input$sourceSubRegion) > 0 && length(input$SubRegion) > 0) {
  		  data <- subset(data, source_subregion %in% input$sourceSubRegion & sub_region %in% input$SubRegion)
  		}
  		
  		# Ports filter
  		if (length(input$sourceports) > 0 && length(input$ports) > 0) {
  		  data <- subset(data, origin_name %in% input$sourceports & pr_port %in% input$ports)
		}
		  }
		}
		# browser()
		first_port <- input$ports[1]
		ports <- port_data()
		matching_row <- ports[match(first_port, ports$name), ]
		leafletProxy("mymap") %>%
		  setView(lng = matching_row$lon, lat = matching_row$lat, zoom = 4)
		
		
	  #browser()
		#idle filter
		if(length(input$idle_cb)==1){
			if(input$idle_cb == "Idle"){
				data <- data[which(data$idle >= input$idle_days),]
			}else{
				data <- data[which(data$idle < input$idle_days),]
			}
		}
		
		#empty_full filter
		data$max_seen_date <- as.character(data$seen_date)
		x <- aggregate(max_seen_date ~ imo, data = data, FUN=max)
		data$max_seen_date <- x$max_seen_date[match(data$imo,x$imo)]
		x <- aggregate(draft ~ imo, data = data[which(as.character(data$seen_date)==data$max_seen_date),], FUN=mean)
		data$fill <- x$draft[match(data$imo,x$imo)]
		data$fill <- ifelse(data$fill > data$empty_draft,1,0)
		
		#max_draft filter
		if(nrow(data[which(data$max_draft <= input$max_draft),]) > 0){
		  data <- data[which(data$max_draft <= input$max_draft),]
		} else {
		  #if result will return no rows, filter to result with at least one row
		  data <- data[which(data$max_draft == min(data$max_draft)),]
		  updateSliderInput(session, 'max_draft', val=min(data$max_draft))
		}
		
		if(length(input$ef_cb)==1){
			if(input$ef_cb == "Empty"){
				data <- data[which(data$fill == 0),]
			}else{
				data <- data[which(data$fill == 1),]
			}
		}
		
			#add color
		color_df <- data.frame(dest=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
		color=c('#89CFF0','#0247FE','#FFAA1D','#F19CBB','#A4C639','#72A0C1','#00FFFF','#006A4E','#FDEE00','#967117'),
		legend=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		data$color <- as.character(color_df$color[match(data$model_dest,color_df$dest)])
		data$color[which(is.na(data$color))] <- "black"
		data <- unique(data)
		return(data)
	})
	
	points_ <- reactive({
		print("points_")
		data <- data_filter()
		points <- data[which(data$seen_date >= (max(data$seen_date,na.rm=T) - hours(input$hourInput))),c("lon","lat","imo","color")] # ERROR
		
			#break date line
		for(imo in unique(points$imo)){
			imo_pt <- points[points$imo==imo,]
			if(nrow(imo_pt)>1){
				a <- 0
				for(r in 1:(nrow(imo_pt)-1)){
					if(abs(imo_pt$lon[r] - imo_pt$lon[r+1])>100) a <- a + .1
					imo_pt$imo[r+1] <- imo_pt$imo[r+1] + a
				}
			}
			points <- points[which(points$imo!=imo),]
			points <- rbind(points,imo_pt)
		}
		print("end: points_")
		return(points)
	})
		
	markers_ <- reactive({
		print("markers_")
		m_data <- data_filter()
		m_data$seen_date <- as.character(m_data$seen_date)
		markers <- aggregate(seen_date ~ imo,data=m_data,FUN=max)
		markers <- merge(markers,m_data)
		markers$gas_volume <- round(((markers$draft*186765.06 + markers$dwt*12.71 + markers$gas_cap*11.92)-1758141.93)/1000000,digits=2)
		markers$fill <- ifelse(markers$draft > markers$empty_draft,1,0)
		markers$gas_volume[which(markers$fill==0)] <- 0
		print("end: markers_")
		return(markers)
	})
	
	output$mymap <- renderLeaflet({
		leaflet() %>%
		addProviderTiles(providers$Esri,
			options = providerTileOptions(noWrap = TRUE)) %>%
		setView(lat = 29.7269629, lng = -93.8740505, zoom = 4)
	})
	
	output$leftpane <- renderUI({
	})
	
	output$ship_count <- renderUI({
		markers <- markers_()
		sc <- yy_ship_count_filter()
		
		str1 <- paste0("Full: ",length(unique(markers$imo[which(markers$fill==1)])), "\n(Bcf: ", round(sum(markers$gas_volume[which(markers$imo %in% unique(markers$imo[which(markers$fill==1)]))]),digits=2),
			")\nEmpty: ",length(unique(markers$imo[which(markers$fill==0)])), "\nNA: ",
			length(unique(markers$imo[which(is.na(markers$fill))])), "\nTotal: ", length(unique(markers$imo)))
		str2 <- paste0("Y/Y: Full: ",length(unique(markers$imo[which(markers$fill==1)])) - length(unique(sc$imo[which(sc$empty_full==1)])),
			"\nEmpty: ",length(unique(markers$imo[which(markers$fill==0)])) - length(unique(sc$imo[which(sc$empty_full==0)])), "\nNA: ",
			length(unique(markers$imo[which(is.na(markers$fill))])) - length(unique(sc$imo[which(is.na(sc$empty_full))])), 
			"\nTotal: ", length(unique(markers$imo)) - length(unique(sc$imo)))
		
		HTML(paste(str1, str2, sep = '<br/>'))
	})
	
	observe({
		print("map")
		if(length(input$dest_cb) > 0){
			markers <- markers_()
			markers$fill[which(is.na(markers$fill))] <- 0 #if NA then show as empty
			ports <- port_data()
			points <- points_()
			
			split_data = lapply(unique(points$imo), function(x) {
			df = as.matrix(points[points$imo == x, c("lon", "lat")])
			lns = Lines(Line(df), ID = x)
			return(lns)
			})
			
			
			line_color <- data.frame(imo=unique(points$imo))
			line_color$color <- points$color[match(line_color$imo,points$imo)]
			
				#color_df
			color_df <- data.frame(dest=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
			color=c('#89CFF0','#0247FE','#FFAA1D','#F19CBB','#A4C639','#72A0C1','#00FFFF','#006A4E','#FDEE00','#967117'),
			legend=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
			
			data_lines <- SpatialLines(split_data)
			terminalIcons <- icons(
			  iconUrl = ifelse(ports$category == "Import",
				"import.png",
				"export.png"
			  ),
			  iconWidth = 17, iconHeight = 23,
			  iconAnchorX = 9, iconAnchorY = 13,
			)
			
			
			html_legend <- "<font size=\"+.5\">Ship Size</font><br/>
			<img src='conv.png'>Conventional<br/>
			<img src='q-flex.png'>Q-Flex<br/>
			<img src='q-max.png'>Q-Max"

			#create map
			leafletProxy("mymap") %>%
			clearShapes() %>%
			clearMarkers() %>%
			clearControls() %>%
			addPolylines(data=data_lines,color=line_color$color) %>%
			addLegend(position="bottomleft",labels=color_df$legend,color=color_df$color) %>%
			addMarkers(icon=terminalIcons,lat=ports$lat,lng=ports$lon,label=lapply(paste0("Name: ",ports$name,"<br/>",
				"Type: ",ports$category,"<br/>",
				"Country: ",ports$country,"<br/>"),HTML)) %>%
			addCircleMarkers(color="black",lng=markers$lon[which(markers$size %in% c("Q-Flex","Q-Max"))],lat=markers$lat[which(markers$size %in% c("Q-Flex","Q-Max"))],fillOpacity=0,
				radius=11, weight=1, opacity=1) %>%
			addCircleMarkers(color="black",lng=markers$lon[which(markers$size %in% c("Q-Max"))],lat=markers$lat[which(markers$size %in% c("Q-Max"))],fillOpacity=0,
				radius=11, weight=3, opacity=1) %>%
			addCircleMarkers(color=markers$color,lng=markers$lon,lat=markers$lat,fillOpacity=markers$fill, radius=8, weight=2, opacity=1,
				label=lapply(paste0(
				"<b>Dest Region:</b> ",markers$model_dest,"<br/>",
				"<b>Dest Sub-Region(Prob):</b>  ",markers$sub_region," (",markers$prob,")<br/>",
				"<b>Dest Port(Prob):</b>  ",markers$pr_port," (",markers$port_prob,")<br/>",
				"<b>Model ETA:</b> ",markers$port_eta,"<br/>",
				"<b>Model Days to Destination:</b> ",round(markers$d2d,digits=2),"<br/>",
				"<b>IMO:</b> ",markers$imo,"<br/>",
				"<b>Name:</b> ",markers$name,"<br/>",
				"<b>Size:</b> ",markers$size,"<br/>",
				"<b>Gas Volume (Bcf):</b> ",round(markers$gas_volume,digits=2),"<br/>",
				"<b>Draft:</b> ",markers$draft,"<br/>",
				"<b>Max Full Draft:</b> ",markers$max_draft,"<br/>",
				"<b>Empty Draft:</b> ",markers$empty_draft,"<br/>",
				"<b>Speed:</b> ",markers$sog,"<br/>",
				"<b>Stated Destination:</b> ",markers$stated_destination,"<br/>",
				"<b>Stated ETA:</b> ",markers$stated_eta,"<br/>",
				"<b>Origin Port:</b> ",markers$origin_name,"<br/>",
				"<b>Origin Country:</b> ",markers$origin_country,"<br/>",
				"<b>Origin Port Type:</b> ",markers$origin_type,"<br/>",
				"<b>Idle Days:</b> ",markers$idle,"<br/>"),HTML)) %>%
			addControl(html = html_legend, position = "bottomleft")
		}
	})
}
)