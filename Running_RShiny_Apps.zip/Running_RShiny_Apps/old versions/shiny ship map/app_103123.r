#shiny::runApp("J:/_Eric Anderson/NG Analysis/LNG/Shiny Ship Map SA v6")
# Built from Shiny Ship Map SA, in v4 added subregion checkbox dropdown
# in v5 added y/y diff for ship counter
# in v6 added max full draft filter
# in v6 switched to RData files(compressed/faster)


library(shiny)
library(leaflet)
library(sp)
library(geosphere)
library(lubridate)
library(rdrop2)
library(shinyWidgets)

regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
regions$sub_region <- as.character(regions$sub_region)
regions$region <- as.character(regions$region)


shinyApp(
ui <- bootstrapPage(
	tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
	leafletOutput("mymap", width = "100%", height = "100%"),
	absolutePanel(top = 10, right = 10,
		wellPanel(
			sliderInput(inputId="hourInput",label="Ship Path Length (hours)",
			step=6,value=72,min=7,max=72),
			checkboxGroupInput("dest_cb","Include Destinations",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s")),
			actionLink("selectall","Select/Unselect All"),
			pickerInput(inputId = "SubRegion",label = "Select Sub-Regions",choices = regions$sub_region,options = list(`actions-box` = TRUE,size = 10,`selected-text-format` = "count > 3"),multiple = TRUE, selected = regions$sub_region),
			checkboxGroupInput("idle_cb","Idle Ships",c("Idle","Active"),c("Idle","Active")),
			checkboxGroupInput("ef_cb","Empty Full",c("Empty","Full"),c("Empty","Full")),
			sliderInput("idle_days","Idle If No Movement In (Days)",1,5,5),
			sliderInput("max_draft","Max Full Draft (Meters)",11,14,14, step=0.25),
			htmlOutput("ship_count")
		)
	)
),

server <- function(input, output, session) {
	ship_data <- reactive({
	  print('loading ship data')
	  data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4bz3qrjqhbevtlqn4w131/imo_tracking.csv?rlkey=w9evtnyx2oo1wwx2sdaw0190r&dl=0")
		print('done')
		# data <- merge(tracking, imo, by="imo", x.all=T)
		
		data$date <- as.Date(data$seen_date)
		data <- data[which(data$imo %in% unique(data$imo)),c("date","lat","lon","imo","seen_date",
			"name","imo","draft","empty_draft","sog","stated_destination","model_dest","prob","stated_eta","d2d","model_eta","size","bcf_cap",
			"origin_name","origin_type","sub_region","idle","gas_cap","dwt", "max_draft", "pr_port", "port_prob", "port_eta")]
		data <- data[complete.cases(data[,c("lat","lon","imo","seen_date")]),]
		data$seen_date <- strptime(data$seen_date,format="%Y-%m-%d %H:%M:%S")
		data <- data[order(data$seen_date),]
		return(data)
	})
	
	port_data <- reactive({
	  print('Loading Port Data')
		ports <- read.csv("https://dl.dropboxusercontent.com/scl/fi/4h83p47fpaz5v1tnhaw69/ports.csv?rlkey=1erpymfq8eq6fzst5dcxi0wt3&dl=0",header=TRUE)
		print('done')
		return(ports)
	})
	
	regions <- reactive({
	  print('Loading regions Data')
		regions <- read.csv("https://dl.dropboxusercontent.com/scl/fi/dhow2fvxtibo46gjget76/regions.csv?rlkey=xsoa08k36f2z8q4rqpy4p29y8&dl=0",header=TRUE)
		regions$sub_region <- as.character(regions$sub_region)
		regions$region <- as.character(regions$region)
		print('done')
		
		return(regions)
	})
	
	yy_ship_count <- reactive({
	  print('Loading yy ship count')
		data <- read.csv("https://dl.dropboxusercontent.com/scl/fi/gzu9k87fxiutcf0q6uqo3/yy_ship_count.csv?rlkey=04hv0trgaoe0myk3pjcsmnu7e&dl=0",header=TRUE)
		print('done')
		return(data)
	})
	
	yy_ship_count_filter <- reactive({
		data <- yy_ship_count()
		
		#regions
		data <- data[which(data$region %in% input$dest_cb),]
		
		#subregions
		filtered_data <- data[which(data$subregion %in% input$SubRegion),]
		if(nrow(filtered_data) > 0){ #do not allow empty sub_region to be passed for filter
			data <- filtered_data
		}
		
		#idle
		if(length(input$idle_cb)==1){
			if(input$idle_cb == "Idle"){
				data <- data[which(data$idle == 1),]
			}else{
				data <- data[which(data$idle == 0),]
			}
		}
		
		#empty_full
		if(length(input$ef_cb)==1){
			if(input$ef_cb == "Empty"){
				data <- data[which(data$empty_full == 0),]
			}else{
				data <- data[which(data$empty_full == 1),]
			}
		}
		
		return(data)
	})
	
	#update subregion picker when checkboxes updated
	observeEvent(input$dest_cb,{
		regions <- regions()
		
		sub_regions <- regions$sub_region[which(regions$region %in% input$dest_cb)]
		updatePickerInput(session = session, inputId = "SubRegion",choices = sub_regions, selected = sub_regions)
	})
	
	observe({
		if(input$selectall == 0) return(NULL) 
		else if (input$selectall%%2 == 0){
			updateCheckboxGroupInput(session,"dest_cb","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		}else{
			updateCheckboxGroupInput(session,"dest_cb","Include Regions",
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
				c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		}
	})

	data_filter <- reactive({
		print("data_filter")
		data <- ship_data()
		
		#add orgin_country
		ports <- port_data()
		data$origin_country <- ports$country[match(data$origin_name,ports$name)]
		
		#Region filter
		data <- data[which(data$model_dest %in% input$dest_cb),]
		
		#SubRegion filter
		filtered_data <- data[which(data$sub_region %in% input$SubRegion),]
		if(nrow(filtered_data) > 0){ #do not allow empty sub_region to be passed for filter
			data <- filtered_data
		}
		
		#idle filter
		if(length(input$idle_cb)==1){
			if(input$idle_cb == "Idle"){
				data <- data[which(data$idle >= input$idle_days),]
			}else{
				data <- data[which(data$idle < input$idle_days),]
			}
		}
		
		#empty_full filter
		data$max_seen_date <- as.character(data$seen_date)
		x <- aggregate(max_seen_date ~ imo, data = data, FUN=max)
		data$max_seen_date <- x$max_seen_date[match(data$imo,x$imo)]
		x <- aggregate(draft ~ imo, data = data[which(as.character(data$seen_date)==data$max_seen_date),], FUN=mean)
		data$fill <- x$draft[match(data$imo,x$imo)]
		data$fill <- ifelse(data$fill > data$empty_draft,1,0)
		
		#max_draft filter
		if(nrow(data[which(data$max_draft <= input$max_draft),]) > 0){
		  data <- data[which(data$max_draft <= input$max_draft),]
		} else {
		  #if result will return no rows, filter to result with at least one row
		  data <- data[which(data$max_draft == min(data$max_draft)),]
		  updateSliderInput(session, 'max_draft', val=min(data$max_draft))
		}
		
		if(length(input$ef_cb)==1){
			if(input$ef_cb == "Empty"){
				data <- data[which(data$fill == 0),]
			}else{
				data <- data[which(data$fill == 1),]
			}
		}
		
			#add color
		color_df <- data.frame(dest=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
		color=c('#89CFF0','#0247FE','#FFAA1D','#F19CBB','#A4C639','#72A0C1','#00FFFF','#006A4E','#FDEE00','#967117'),
		legend=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
		data$color <- as.character(color_df$color[match(data$model_dest,color_df$dest)])
		data$color[which(is.na(data$color))] <- "black"
		data <- unique(data)
		return(data)
	})
	
	points_ <- reactive({
		print("points_")
		data <- data_filter()
		points <- data[which(data$seen_date >= (max(data$seen_date,na.rm=T) - hours(input$hourInput))),c("lon","lat","imo","color")] # ERROR
		
			#break date line
		for(imo in unique(points$imo)){
			imo_pt <- points[points$imo==imo,]
			if(nrow(imo_pt)>1){
				a <- 0
				for(r in 1:(nrow(imo_pt)-1)){
					if(abs(imo_pt$lon[r] - imo_pt$lon[r+1])>100) a <- a + .1
					imo_pt$imo[r+1] <- imo_pt$imo[r+1] + a
				}
			}
			points <- points[which(points$imo!=imo),]
			points <- rbind(points,imo_pt)
		}
		print("end: points_")
		return(points)
	})
		
	markers_ <- reactive({
		print("markers_")
		m_data <- data_filter()
		m_data$seen_date <- as.character(m_data$seen_date)
		markers <- aggregate(seen_date ~ imo,data=m_data,FUN=max)
		markers <- merge(markers,m_data)
		markers$gas_volume <- round(((markers$draft*186765.06 + markers$dwt*12.71 + markers$gas_cap*11.92)-1758141.93)/1000000,digits=2)
		markers$fill <- ifelse(markers$draft > markers$empty_draft,1,0)
		markers$gas_volume[which(markers$fill==0)] <- 0
		print("end: markers_")
		return(markers)
	})
	
	output$mymap <- renderLeaflet({
		leaflet() %>%
		addProviderTiles(providers$Esri,
			options = providerTileOptions(noWrap = TRUE)) %>%
		setView(lat = 29.7269629, lng = -93.8740505, zoom = 4)
	})
	
	output$ship_count <- renderUI({
		markers <- markers_()
		sc <- yy_ship_count_filter()
		
		str1 <- paste0("Full: ",length(unique(markers$imo[which(markers$fill==1)])), "\n(Bcf: ", round(sum(markers$gas_volume[which(markers$imo %in% unique(markers$imo[which(markers$fill==1)]))]),digits=2),
			")\nEmpty: ",length(unique(markers$imo[which(markers$fill==0)])), "\nNA: ",
			length(unique(markers$imo[which(is.na(markers$fill))])), "\nTotal: ", length(unique(markers$imo)))
		str2 <- paste0("Y/Y: Full: ",length(unique(markers$imo[which(markers$fill==1)])) - length(unique(sc$imo[which(sc$empty_full==1)])),
			"\nEmpty: ",length(unique(markers$imo[which(markers$fill==0)])) - length(unique(sc$imo[which(sc$empty_full==0)])), "\nNA: ",
			length(unique(markers$imo[which(is.na(markers$fill))])) - length(unique(sc$imo[which(is.na(sc$empty_full))])), 
			"\nTotal: ", length(unique(markers$imo)) - length(unique(sc$imo)))
		
		HTML(paste(str1, str2, sep = '<br/>'))
	})
	
	observe({
		print("map")
		if(length(input$dest_cb) > 0){
			markers <- markers_()
			markers$fill[which(is.na(markers$fill))] <- 0 #if NA then show as empty
			ports <- port_data()
			points <- points_()
			
			split_data = lapply(unique(points$imo), function(x) {
			df = as.matrix(points[points$imo == x, c("lon", "lat")])
			lns = Lines(Line(df), ID = x)
			return(lns)
			})
			
			
			line_color <- data.frame(imo=unique(points$imo))
			line_color$color <- points$color[match(line_color$imo,points$imo)]
			
				#color_df
			color_df <- data.frame(dest=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"),
			color=c('#89CFF0','#0247FE','#FFAA1D','#F19CBB','#A4C639','#72A0C1','#00FFFF','#006A4E','#FDEE00','#967117'),
			legend=c("Africa","Asia Pacific","Australia","Central Asia","Eastern Europe","Middle East","North America","South & Central America","Western Europe", "s2s"))
			
			data_lines <- SpatialLines(split_data)
			terminalIcons <- icons(
			  iconUrl = ifelse(ports$category == "Import",
				"import.png",
				"export.png"
			  ),
			  iconWidth = 17, iconHeight = 23,
			  iconAnchorX = 9, iconAnchorY = 13,
			)
			
			
			html_legend <- "<font size=\"+.5\">Ship Size</font><br/>
			<img src='conv.png'>Conventional<br/>
			<img src='q-flex.png'>Q-Flex<br/>
			<img src='q-max.png'>Q-Max"

			#create map
			leafletProxy("mymap") %>%
			clearShapes() %>%
			clearMarkers() %>%
			clearControls() %>%
			addPolylines(data=data_lines,color=line_color$color) %>%
			addLegend(position="bottomleft",labels=color_df$legend,color=color_df$color) %>%
			addMarkers(icon=terminalIcons,lat=ports$lat,lng=ports$lon,label=lapply(paste0("Name: ",ports$name,"<br/>",
				"Type: ",ports$category,"<br/>",
				"Country: ",ports$country,"<br/>"),HTML)) %>%
			addCircleMarkers(color="black",lng=markers$lon[which(markers$size %in% c("Q-Flex","Q-Max"))],lat=markers$lat[which(markers$size %in% c("Q-Flex","Q-Max"))],fillOpacity=0,
				radius=11, weight=1, opacity=1) %>%
			addCircleMarkers(color="black",lng=markers$lon[which(markers$size %in% c("Q-Max"))],lat=markers$lat[which(markers$size %in% c("Q-Max"))],fillOpacity=0,
				radius=11, weight=3, opacity=1) %>%
			addCircleMarkers(color=markers$color,lng=markers$lon,lat=markers$lat,fillOpacity=markers$fill, radius=8, weight=2, opacity=1,
				label=lapply(paste0(
				"Destination: ",markers$model_dest,"<br/>",
				"Destination port: ",markers$pr_port,"<br/>",
				"Probability: ",markers$prob,"<br/>",
				"Probability (port): ",markers$port_prob,"<br/>",
				"Sub-Region Destination: ",markers$sub_region,"<br/>",
				"Name: ",markers$name,"<br/>",
				"IMO: ",markers$imo,"<br/>",
				"Size: ",markers$size,"<br/>",
				"Gas Volume (Bcf): ",round(markers$gas_volume,digits=2),"<br/>",
				"Draft: ",markers$draft,"<br/>",
				"Max Full Draft: ",markers$max_draft,"<br/>",
				"Speed: ",markers$sog,"<br/>",
				"Stated Destination: ",markers$stated_destination,"<br/>",
				"Stated ETA: ",markers$stated_eta,"<br/>",
				"Model Days to Destination: ",round(markers$d2d,digits=2),"<br/>",
				"Model ETA: ",markers$model_eta,"<br/>",
				"Port Model ETA: ",markers$port_eta,"<br/>",
				"Origin Port: ",markers$origin_name,"<br/>",
				"Origin Country: ",markers$origin_country,"<br/>",
				"Origin Port Type: ",markers$origin_type,"<br/>",
				"Idle Days: ",markers$idle,"<br/>"),HTML)) %>%
			addControl(html = html_legend, position = "topleft")
		}
	})
}
)